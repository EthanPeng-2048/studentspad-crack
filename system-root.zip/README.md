magisk-on-system by Anonymous   (测试版本)

文件夹需要放入指定位置
bin --> /system/bin
data-magisk --> /data/adb/
init --> /system/etc/
magisk --> /system/etc/init/

安装Kitsune-Mask:前往whhhh.cloud下载26.4-kitsune-2.apk